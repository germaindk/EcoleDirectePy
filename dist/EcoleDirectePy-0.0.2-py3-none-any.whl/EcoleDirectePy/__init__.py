from main import __init__,login,emploidutemps,cahierdetexte,notes,messages
